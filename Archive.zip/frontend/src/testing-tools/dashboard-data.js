export const DashboardData = [
  {
    id: 1,
    createdAt: "2021-08-11T13:38:49.000Z",
    updatedAt: "2021-08-11T13:38:49.000Z",
    title: "AAA",
  },
  {
    id: 2,
    createdAt: "2021-08-11T13:38:49.000Z",
    updatedAt: "2021-08-11T13:38:49.000Z",
    title: "BBB",
  },
  {
    id: 3,
    createdAt: "2021-08-11T13:38:49.000Z",
    updatedAt: "2021-08-11T13:38:49.000Z",
    title: "B2B",
  },
  {
    id: 4,
    createdAt: "2021-08-11T13:38:49.000Z",
    updatedAt: "2021-08-11T13:38:49.000Z",
    title: "B2C",
  },
  {
    id: 5,
    createdAt: "2021-08-11T13:38:49.000Z",
    updatedAt: "2021-08-11T13:38:49.000Z",
    title: "22B",
  },
  {
    id: 6,
    createdAt: "2021-08-11T13:38:49.000Z",
    updatedAt: "2021-08-11T13:38:49.000Z",
    title: "133",
  },
  {
    id: 7,
    createdAt: "2021-08-11T13:38:49.000Z",
    updatedAt: "2021-08-11T13:38:49.000Z",
    title: "TDD",
  },
  {
    id: 8,
    createdAt: "2021-08-11T13:38:49.000Z",
    updatedAt: "2021-08-11T13:38:49.000Z",
    title: "BFD",
  },
  {
    id: 9,
    createdAt: "2021-08-11T13:38:49.000Z",
    updatedAt: "2021-08-11T13:38:49.000Z",
    title: "1FF",
  },
  {
    id: 10,
    createdAt: "2021-08-11T13:38:49.000Z",
    updatedAt: "2021-08-11T13:38:49.000Z",
    title: "CCC",
  },
];
