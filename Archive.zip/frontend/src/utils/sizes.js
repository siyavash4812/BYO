export const FontSize = {
  S: "1em",
  M: "1.5em",
  L: "2em",
};
