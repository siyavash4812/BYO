const dashboardRoutes = require('./dashboard.routes');

module.exports = {
    dashboardRoutes
}