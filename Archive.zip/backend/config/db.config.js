module.exports = {
  HOST: "mysql-db",
  USER: "root",
  PASSWORD: "test123",
  DB: "definitions",
};
